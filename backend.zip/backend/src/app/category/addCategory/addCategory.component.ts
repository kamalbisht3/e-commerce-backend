import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CategoryService } from '../category.service';
declare var $: any;

@Component({
  selector: 'app-addCategory',
  templateUrl: './addCategory.component.html',
  styleUrls: ['./addCategory.component.css']
})
export class AddCategoryComponent implements OnInit {

  addCategoryFormGroup: FormGroup;
  cateogoryList: Array<any> = [];
  fileToUpload: File = null;
  constructor(private categoryService: CategoryService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.getCategoryList();
    this.addCategoryFormGroup = this.formBuilder.group(
      {
        name: ['', [Validators.required]],
        description: ['', []],
        parent: ['', []]
      }
    )
  }

  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);
    var reader = new FileReader();
    reader.onload = this.imageIsLoaded;
    reader.readAsDataURL(files[0]);
    console.log(this.fileToUpload);
  }



  imageIsLoaded(e) {
    // alert(e.target.result);
    $('#product-image').attr('src', e.target.result);
  };
  addCategory(formValue) {
    let formdata = [
      { key: "name", value: this.addCategoryFormGroup.controls['name'].value },
      { key: "description", value: this.addCategoryFormGroup.controls['description'].value },
      { key: "parent", value: this.addCategoryFormGroup.controls['parent'].value },
      { key: 'icon', value: this.fileToUpload }
    ]
    let xhr = new XMLHttpRequest();
    xhr = this.categoryService.addCategory(formdata);
    xhr.onreadystatechange = (function (request: XMLHttpRequest, event: Event) {
      if (request.readyState == 4 && request.status == 200) {
        let res: any = request.responseText;
        res = JSON.parse(res);
        if (res.status == "success") {
          this.showNotification("top", "center", "Category Created Successfully");
        }
        else
          this.showNotification("top", "center", "Something went wrong");

      }
    }).bind(this, xhr);



  }

  showNotification(from: any, align: any, message) {
    const type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

    const color = Math.floor((Math.random() * 6) + 1);

    $.notify({
      icon: 'notifications',
      message: message
    }, {
        type: type[color],
        timer: 1000,
        placement: {
          from: from,
          align: align
        }
      });
  }

  getCategoryList() {
    this.categoryService.getCategoryList().subscribe((data) => {
      let res = data;
      if (res.status = "success") {
        this.cateogoryList = res.data;
      }
    })
  }

  isFieldValid(form: FormGroup, field: string) {
    return !form.get(field).valid && form.get(field).touched;
  }

  displayFieldCss(form: FormGroup, field: string) {
    return {
      'has-error': this.isFieldValid(form, field),
      'has-feedback': this.isFieldValid(form, field)
    };
  }

}
