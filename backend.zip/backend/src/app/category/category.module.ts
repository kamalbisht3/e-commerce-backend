import { NgModule } from '@angular/core';

import { CategoryComponent } from './category.component';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
//import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { CategoryRoutes } from './category.routing';
import { CategoryService } from './category.service'
import { AddCategoryComponent } from './addCategory/addCategory.component';
import { UpdateCategoryComponent } from './updateCategory/updateCategory.component';
// import { FileUploadModule } from 'ng2-file-upload';
import { FieldErrorDisplayModule } from '../forms/validationforms/field-error-display/field-error-display.component';
import {
   
    MatSelectModule
  
  } from '@angular/material';

@NgModule({
    imports: [CommonModule,
        RouterModule.forChild(CategoryRoutes),
        ReactiveFormsModule,
        MatSelectModule,
        FieldErrorDisplayModule
        //FileUploadModule
    ],
    exports: [CategoryComponent],
    declarations: [CategoryComponent,
        AddCategoryComponent,
        UpdateCategoryComponent
    ],
    providers: [CategoryService],
})
export class CategoryModule { }
