import { Routes } from '@angular/router';
import { CategoryComponent } from './category.component';
import { UpdateCategoryComponent } from './updateCategory/updateCategory.component';
import { AddCategoryComponent } from './addCategory/addCategory.component';



export const CategoryRoutes: Routes = [
    {
        path: '',
        children: [{
            path: '',
            component: CategoryComponent
        },
        {
            path: 'add',
            component: AddCategoryComponent
        },
        {
            path: 'update/:id',
            component: UpdateCategoryComponent
        }]
    }
];