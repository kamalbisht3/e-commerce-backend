import { Component, OnInit } from '@angular/core';
import { CategoryService } from './category.service';


@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

  constructor(private categoryService: CategoryService) { }

  cateogoryList: Array<any> = [];

  ngOnInit() {
    this.getCategoryList();
  }



  deleteCategory(item) {
    this.categoryService.deleteCategory(item.id).subscribe((data) => {
      this.getCategoryList();
    });
  }

  getCategoryList() {
    this.categoryService.getCategoryList().subscribe((data) => {
      let res = data;
      if (res.status = "success") {
        this.cateogoryList = res.data;
      }
    })
  }

}
