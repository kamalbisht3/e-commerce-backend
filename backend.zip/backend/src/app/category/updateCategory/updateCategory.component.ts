import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CategoryService } from '../category.service';
declare var $: any;
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-updateCategory',
  templateUrl: './updateCategory.component.html',
  styleUrls: ['./updateCategory.component.css']
})
export class UpdateCategoryComponent implements OnInit {

  addCategoryFormGroup: FormGroup;
  cateogoryList: Array<any> = [];
  fileToUpload: File = null;
  categoryId: string;
  imagePath:null;
  constructor(private activatedRoute: ActivatedRoute, private categoryService: CategoryService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe((data) => {
      this.categoryId = data['id'];
      this.getCategoryList(this.categoryId);
    })

    this.addCategoryFormGroup = this.formBuilder.group(
      {
        name: ['', [Validators.required]],
        description: ['', []],
        parent: ['', []]
      }
    )
  }

  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);
   // console.log(this.fileToUpload);
  }

  updateCategory(formValue) {
    

    let formdata = [
      { key: "id", value: this.categoryId },
      { key: "name", value: this.addCategoryFormGroup.controls['name'].value },
      { key: "description", value: this.addCategoryFormGroup.controls['description'].value },
      { key: "parent", value: this.addCategoryFormGroup.controls['parent'].value }
      
    ];
    if(this.fileToUpload)
    {
      formdata.push({ key: 'icon', value:this.fileToUpload});
    }
    let xhr = new XMLHttpRequest();
    xhr = this.categoryService.updateCategory(formdata);
    xhr.onreadystatechange = (function (request: XMLHttpRequest, event: Event) {
      if (request.readyState == 4 && request.status == 200) {
        let res: any = request.responseText;
        res = JSON.parse(res);
        if (res.status == "success") {
          this.showNotification("top", "center", "Category Updated Successfully");
        }
        else
          this.showNotification("top", "center", "Something went wrong");

      }
    }).bind(this, xhr);
  }

 

  showNotification(from: any, align: any, message) {
    const type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

    const color = Math.floor((Math.random() * 6) + 1);

    $.notify({
      icon: 'notifications',
      message: message
    }, {
        type: type[color],
        timer: 1000,
        placement: {
          from: from,
          align: align
        }
      });
  }

  getCategoryList(id) {
    this.categoryService.getCategoryList().subscribe((data) => {
      let res = data;
      if (res.status = "success") {
        this.cateogoryList = res.data;
        this.getCategoryById(id);
      }
    })
  }

  getCategoryById(id) {
    this.categoryService.getCategoryById(id).subscribe((data) => {
      let res = data;
      if (res.status == "success") {
        this.addCategoryFormGroup.controls['name'].setValue(res.data.name);
        if (res.data.parent && res.data.parent !== "")
          this.addCategoryFormGroup.controls['parent'].setValue(res.data.parent.id);
        this.addCategoryFormGroup.controls['description'].setValue(res.data.description);
        this.imagePath=res.data.icon;
        //this.fileToUpload = res.data.icon
      }
    });
  }

  isFieldValid(form: FormGroup, field: string) {
    return !form.get(field).valid && form.get(field).touched;
  }

  displayFieldCss(form: FormGroup, field: string) {
    return {
      'has-error': this.isFieldValid(form, field),
      'has-feedback': this.isFieldValid(form, field)
    };
  }

}
