import { Injectable } from '@angular/core';
import { DataService } from '../services/data.service';
import { Observable } from 'rxjs';

@Injectable()
export class CategoryService {

    constructor(private dataService: DataService) { }

    getCategoryList(): Observable<any> {
        let url = this.dataService.baseApiPath + "catalog/categories";
        return this.dataService.callRestful("GET", url);
    }

    getCategoryById(id): Observable<any> {
        let url = this.dataService.baseApiPath + "catalog/category/" + id;
        return this.dataService.callRestful("GET", url);
    }

    addCategory(formDataArray): any {
        let url = this.dataService.baseApiPath + "admin/catalog/category";

        return this.dataService.callRestfulWithFormData("POST",url, formDataArray);
    }



    updateCategory(formDataArray):any {
        let url = this.dataService.baseApiPath + "admin/catalog/category/update";
        return this.dataService.callRestfulWithFormData("POST",url, formDataArray);
    }

    deleteCategory(id): Observable<any> {
        let url = this.dataService.baseApiPath + "admin/catalog/category/" + id;
        return this.dataService.callRestful("DELETE", url);
    }
}