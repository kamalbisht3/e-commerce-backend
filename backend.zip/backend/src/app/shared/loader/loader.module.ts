import { NgModule,ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoaderComponent } from './loader.component';
import { LoaderService } from './loader.component.service';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [LoaderComponent],
  providers: [LoaderService],
  exports: [LoaderComponent]
})


export class LoaderModule {
  static forRoot(): ModuleWithProviders {
      return {
          ngModule: LoaderModule,
          providers: [LoaderService]
      };
  }
}