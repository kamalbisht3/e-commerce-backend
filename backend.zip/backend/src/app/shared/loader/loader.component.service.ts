import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable()
export class LoaderService {
    private isShowLoader: boolean = true;
    public isShowLoaderSubject: Subject<boolean> = new Subject<any>();
    constructor() {
       
    }

    set loader(value: boolean) {
        this.isShowLoader = value;
    }

    get loader(): boolean {
        return this.isShowLoader;
    }

    emitEvent(value) {
        this.isShowLoaderSubject.next(value);
    }

    public start() {
      
        this.emitEvent(true);
    }

    stop() {
        this.emitEvent(false);
    }

}