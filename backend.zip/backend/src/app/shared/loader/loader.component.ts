import { Component, OnInit } from '@angular/core';
import { LoaderService } from './loader.component.service';

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.css']
})
export class LoaderComponent implements OnInit {

  isShow: boolean = false;

  constructor(private loaderService: LoaderService) { }

  ngOnInit() {
    
    this.loaderService.isShowLoaderSubject.subscribe((data) => {
    
      this.isShow = data;
    })
  }

}
