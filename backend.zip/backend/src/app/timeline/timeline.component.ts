import { Component } from '@angular/core';

@Component({
    selector: 'app-timeline-cmp',
    templateUrl: 'timeline.component.html'
})

export class TimelineComponent {}
