import { Injectable } from '@angular/core';
import { DataService } from '../services/data.service';
import { Observable } from 'rxjs';

@Injectable()
export class FeedbackService {

    constructor(private dataService:DataService) { }

    getFeedbackList():Observable<any>
    {
        let url=this.dataService.baseApiPath+"feedback";
        return this.dataService.callRestful("GET",url);            
    }

    addFeedback(obj):Observable<any>
    {
        let url=this.dataService.baseApiPath+"feedback";
        return this.dataService.callRestful("POST",url,{body:obj});
    }

    updateFeedback(id):Observable<any>
    {
        let url=this.dataService.baseApiPath+"admin/feedback/"+id;
        return this.dataService.callRestful("POST",url);
    }

    deleteFeedbackById(id):Observable<any>
    {
        let url=this.dataService.baseApiPath+"admin/feedback/"+id;
        return this.dataService.callRestful("DELETE",url);
    }
    
    getProduct():Observable<any>
    {
      let url=this.dataService.baseApiPath+"catalog/products";
      return this.dataService.callRestful("GET",url);
    }
}