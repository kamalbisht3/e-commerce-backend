import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { FeedbackService } from '../feedback.service';
import { ActivatedRoute } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-addFeedback',
  templateUrl: './updateFeedback.component.html',
  styleUrls: ['./updateFeedback.component.css']
})
export class UpdateFeedbackComponent implements OnInit {


  feedBackFormGroup: FormGroup;

  productList: Array<any> = [];

  ratings: any;

  constructor(private activatedRoute: ActivatedRoute, private formBuilder: FormBuilder, private feedbackService: FeedbackService) { }

  ngOnInit() {

    this.getProductList();

    this.feedBackFormGroup = this.formBuilder.group({
      product_id: ['', [Validators.required]],
      review: ['', [Validators.required]],
      rating: ['', [Validators.required]]
    })

  }

  getProductList() {
    this.feedbackService.getProduct().subscribe((data) => {
      if (data.status) {
        this.productList = data.data;
        this.activatedRoute.params.subscribe((data) => {
         // this.feedbackService.
        })
      }
    })
  }




  addFeedback(formValue) {
    this.feedbackService.addFeedback(formValue).subscribe((data) => {
      if (data.status == "success") {
        this.showNotification("top", "center", data.data)
      }
      else {
        this.showNotification("top", "center", data.error.message[0]);
      }
    })
  }

  showNotification(from: any, align: any, message) {
    const type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

    const color = Math.floor((Math.random() * 6) + 1);

    $.notify({
      icon: 'notifications',
      message: message
    }, {
        type: type[color],
        timer: 1000,
        placement: {
          from: from,
          align: align
        }
      });
  }

}
