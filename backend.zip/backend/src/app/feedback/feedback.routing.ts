import { Routes } from '@angular/router';
import { FeedbackComponent } from './feedback.component';
import { AddFeedbackComponent } from './addFeedback/addFeedback.component';
import { UpdateFeedbackComponent } from './updateFeedback/updateFeedback.component';

export const FeedbackRoutes:Routes=[
    {
        path: '',
        children: [
            {
                path: '',
                component: FeedbackComponent
            },
            {
                path: 'add',
                component: AddFeedbackComponent
            },
            {
                path: 'update/:id',
                component: UpdateFeedbackComponent
            }
            // {
            //     path: 'update/:id',
            //     component: UpdateProductVariantOptionComponent
            // }
        ]
    }
]
