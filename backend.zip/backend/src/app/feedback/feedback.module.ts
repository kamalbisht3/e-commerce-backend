import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FeedbackComponent } from './feedback.component';
import { FeedbackRoutes } from './feedback.routing';
import { FeedbackService } from './feedback.service';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { FieldErrorDisplayModule } from '../forms/validationforms/field-error-display/field-error-display.component';
import { MatSelectModule } from '@angular/material';
import { AddFeedbackComponent } from './addFeedback/addFeedback.component';
// import { RatingModule } from "ng2-rating";
import { UpdateFeedbackComponent } from './updateFeedback/updateFeedback.component';
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(FeedbackRoutes),
    ReactiveFormsModule,
    FieldErrorDisplayModule,
    MatSelectModule,
   // RatingModule,
    FormsModule
  ],
  declarations: [FeedbackComponent,
    AddFeedbackComponent,
    UpdateFeedbackComponent
],
  providers:[FeedbackService]
})


export class FeedbackModule { }
