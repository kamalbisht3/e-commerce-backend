import { Component, OnInit } from '@angular/core';
import { FeedbackService } from './feedback.service';
@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

  feedbackList:Array<any>=[];

  constructor(private feedbackService:FeedbackService) { }

  ngOnInit() {
    this.getFeedbackList();
  }

  getFeedbackList()
  {
     this.feedbackService.getFeedbackList().subscribe((data)=>
    {
      if(data.status=="success")
      this.feedbackList=data.data.data;
    })
  }

}
 