import { Routes } from '@angular/router';
import { ProductComponent } from './product.component';
import { AddProductComponent } from './addProduct/addProduct.component';
import { UpdateProductComponent } from './updateProduct/updateProduct.component';



export const ProductRoutes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                component: ProductComponent
            },
            {
                path: 'add',
                component: AddProductComponent
            },
            {
                path: 'update/:id',
                component: UpdateProductComponent
            }
        ]
    }
];