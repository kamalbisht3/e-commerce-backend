import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormControl, FormBuilder, Validators } from '@angular/forms';
import { ProductService } from '../product.service'
import { TagService } from '../../tag/tag.service';
import { CategoryService } from '../../category/category.service';
declare var $: any;
@Component({
  selector: 'app-addProduct',
  templateUrl: './addProduct.component.html',
  styleUrls: ['./addProduct.component.css']
})
export class AddProductComponent implements OnInit {

  addProductFormGroup: FormGroup;
  tagList: Array<any> = [];
  productTypeList: Array<any> = [];
  categoryList: Array<any> = [];
  fileToUpload: File = null;
  attributes: FormArray;
  constructor(private productService: ProductService, private formBuilder: FormBuilder, private tagService: TagService, private categoryService: CategoryService) { }

  ngOnInit() {

    this.productTypeList.push(
      { name: "Simple", value: "simple" },
      { name: "Variable", value: "variable" }
    );

    this.getCategoryList();
    this.getTags();
    this.addProductFormGroup = this.formBuilder.group(
      {
        name: ['', [Validators.required]],
        description: [''],
        productType: [''],
        price: [''],
        onSale: [true],
        category: [[]],
        tag: [[]],
        discount: [''],
        stockAmount: [''],
        attributes: this.formBuilder.array([this.createArrtibutes()])


      }, { updateOn: 'blur' }
    )

   
  }

  createArrtibutes(): FormGroup {
    return this.formBuilder.group(
      {
        key: ['', [Validators.required]],
        value: ['', [Validators.required]]
      }
    )
  }

  addAttibutes(): void {
    this.attributes = this.addProductFormGroup.get('attributes') as FormArray;
    this.attributes.push(this.createArrtibutes());
  }

  removeAttributes(i) {

    this.attributes.removeAt(i);

  }

  getCategoryList() {
    debugger;
    this.categoryService.getCategoryList().subscribe((data) => {
      let res = data;
      if (res.status = "success") {
        this.categoryList = res.data;
      }
    })
  }

  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);
    var reader = new FileReader();
    reader.onload = this.imageIsLoaded;
    reader.readAsDataURL(files[0]);
    //console.log(this.fileToUpload);
  }

  getTags() {
    this.tagService.getTag().subscribe((data) => {
      let res = data;
      if (res.status == "success") {
        this.tagList = res.data;
      }
    })
  }

  imageIsLoaded(e) {
    // alert(e.target.result);
    $('#product-image').attr('src', e.target.result);
  };

  addProduct() {
    debugger;
     let formValue = this.addProductFormGroup.value;
    // let formValue = {
    //   "name": "postman product key9",
    //   "description": "postman description",
    //   "productType": "variable",
    //   "price": 1000,
    //   "onSale": true,
    //   "category": ["188a5d60-3b1b-11e8-a99c-774919526b83"],
    //   "tag": ["ed295190-3967-11e8-8956-110f08fae0d9"],
    //   "discount": 0,
    //   "stockAmount": 30,
    //   "attributes": [
    //    { "key": "key", "value": "value" },
    //    { "key": "key", "value": "value" }
    //   ]
    // }
    //console.log(formValue);
    let result = Object.keys(formValue).map(function (key) {
      return { "key": key, "value": formValue[key] };
    });
    console.log(result);
     result.push({ "key": "thumbnail", "value": this.fileToUpload })

    let xhr = new XMLHttpRequest();
    xhr = this.productService.addProduct(result);
    xhr.onreadystatechange = (function (request: XMLHttpRequest, event: Event) {
      if (request.readyState == 4 && request.status == 200) {
        let res: any = request.responseText;
        res = JSON.parse(res);
        if (res.status == "success") {
          this.showNotification("top", "center", "Product Created Successfully");
        }
        else
          this.showNotification("top", "center", res.error.message[0]);

      }
    }).bind(this, xhr);




  }

  showNotification(from: any, align: any, message) {
    const type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

    const color = Math.floor((Math.random() * 6) + 1);

    $.notify({
      icon: 'notifications',
      message: message
    }, {
        type: type[color],
        timer: 1000,
        placement: {
          from: from,
          align: align
        }
      });
  }





}
