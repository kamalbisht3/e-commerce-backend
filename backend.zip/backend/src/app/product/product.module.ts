import { NgModule } from '@angular/core';

import { ProductComponent } from './product.component';

import { RouterModule } from '@angular/router';

import { CommonModule } from '@angular/common';

import { FormsModule } from '@angular/forms';

import { ReactiveFormsModule } from '@angular/forms';

import { ProductRoutes } from './product.routing';

import { ProductService } from './product.service';
import { AddProductComponent } from './addProduct/addProduct.component';
import { UpdateProductComponent } from './updateProduct/updateProduct.component';

import { MatSelectModule } from '@angular/material';
import { TagService } from '../tag/tag.service';
import { CategoryService } from '../category/category.service';

@NgModule({
    imports: [RouterModule.forChild(ProductRoutes),
        CommonModule,
        ReactiveFormsModule, FormsModule, MatSelectModule
    ],
    exports: [ProductComponent],
    declarations: [ProductComponent,
        AddProductComponent,
        UpdateProductComponent
    ],
    providers: [ProductService, TagService, CategoryService]
})
export class ProductModule { }
