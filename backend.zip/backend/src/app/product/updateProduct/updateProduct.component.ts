import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { ProductService } from '../product.service'
import { TagService } from '../../tag/tag.service';
import { CategoryService } from '../../category/category.service';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
declare var $: any;
@Component({
  selector: 'app-addProduct',
  templateUrl: './updateProduct.component.html',
  styleUrls: ['./updateProduct.component.css']
})
export class UpdateProductComponent implements OnInit {

  addProductFormGroup: FormGroup;
  tagList: Array<any> = [];
  productTypeList: Array<any> = [];
  categoryList: Array<any> = [];
  fileToUpload: File = null;
  productId: string;
  imagePath: string;
  attributes: FormArray;
  constructor(private activatedRoute: ActivatedRoute, private productService: ProductService, private formBuilder: FormBuilder, private tagService: TagService, private categoryService: CategoryService) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe((data) => {
      this.productId = data['id'];

    })
    this.productTypeList.push(
      { name: "Simple", value: "simple" },
      { name: "Variable", value: "variable" }
    );

    this.getCategoryList();

    this.addProductFormGroup = this.formBuilder.group(
      {
        name: ['', [Validators.required]],
        description: [''],
        productType: [''],
        price: [''],
        onSale: [false],
        category: [[]],
        tag: [[]],
        discount: [''],
        stockAmount: [''],
        attributes: this.formBuilder.array([this.createArrtibutes()])



      }, { updateOn: 'blur' }
    )
  }

  createArrtibutes(): FormGroup {
    return this.formBuilder.group(
      {
        key: ['', [Validators.required]],
        value: ['', [Validators.required]]
      }
    )
  }

  addAttibutes(): void {
    this.attributes = this.addProductFormGroup.get('attributes') as FormArray;
    this.attributes.push(this.createArrtibutes());
  }

  removeAttributes(i) {

    this.attributes.removeAt(i);

  }

  getProductById(id) {
    this.productService.getProductById(id).subscribe((data) => {
      let res: any = data;
      if (res.status = "success") {
        this.addProductFormGroup.controls['name'].setValue(res.data.name);
        this.addProductFormGroup.controls['description'].setValue(res.data.description);

        this.addProductFormGroup.controls['category'].setValue(this.singleArray(res.data.category));
        this.addProductFormGroup.controls['tag'].setValue(this.singleArray(res.data.tags));
        this.addProductFormGroup.controls['price'].setValue(res.data.price);
        this.addProductFormGroup.controls['discount'].setValue(res.data.discount);
        this.addProductFormGroup.controls['onSale'].setValue(this.convertOnSaleValue(res.data.onSale));

        this.addProductFormGroup.controls['stockAmount'].setValue(res.data.stockAmount);
        this.addProductFormGroup.controls['productType'].setValue(res.data.productType);
        this.setAttributesValue(res.data.attributes);
        this.imagePath = res.data.thumbnail;
      }
    })
  }

  setAttributesValue(value) {
    let control = <FormArray>this.addProductFormGroup.controls.attributes;
    // control.reset();
    // alert(control.length);
    if (value.length > 0) {
      control.removeAt(0);
    }
    value.forEach(x => {
      control.push(this.formBuilder.group({ key: x.key, value: x.value }))
    });

    // alert(this.addProductFormGroup.controls['attributes'].);
    // //alert(this.addProductFormGroup.controls['attributes'].);
  }

  convertOnSaleValue(value) {
    if (value == "true") {
      return true;
    }
    else if (value == "false") {
      return false;
    }
    else {
      return false;
    }
  }

  singleArray(input: Array<any>) {
    let ids = [];
    if (input) {
      input.forEach((element) => {
        ids.push(element.id)
      });

      return ids;
    }
    else {
      return ids;
    }
  }

  getCategoryList() {
    //this.categoryService.getCategoryList().flatMap
    let categoryList = this.categoryService.getCategoryList();
    let tagList = this.categoryService.getCategoryList();
    let result = Observable.create(
      (observer) => {
        observer.next(categoryList);
        observer.next(tagList);
        observer.complete();
      }
    );

    this.categoryService.getCategoryList().subscribe((data) => {
      let res = data;

      if (res.status == "success") {
        this.categoryList = res.data;
        this.getTags();
      }
    })
  }

  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);
    var reader = new FileReader();
    reader.onload = this.imageIsLoaded;
    reader.readAsDataURL(files[0]);
    // console.log(this.fileToUpload);
  }

  getTags() {
    this.tagService.getTag().subscribe((data) => {
      let res = data;
      if (res.status == "success") {
        this.tagList = res.data;
        this.getProductById(this.productId);
      }
    })
  }

  updateProduct() {
    let formValue = this.addProductFormGroup.value;

    let result = Object.keys(formValue).map(function (key) {
      return { "key": key, "value": formValue[key] };
    });
    if (this.fileToUpload)
      result.push({ "key": "thumbnail", "value": this.fileToUpload })

    let xhr = new XMLHttpRequest();
    xhr = this.productService.addProduct(result);
    xhr.onreadystatechange = (function (request: XMLHttpRequest, event: Event) {
      if (request.readyState == 4 && request.status == 200) {
        let res: any = request.responseText;
        res = JSON.parse(res);
        if (res.status == "success") {
          this.showNotification("top", "center", "Product updated Successfully");
        }
        else
          this.showNotification("top", "center", res.error.message[0]);

      }
    }).bind(this, xhr);




  }

  imageIsLoaded(e) {
    $('#product-image').attr('src', e.target.result);
  };

  showNotification(from: any, align: any, message) {
    const type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

    const color = Math.floor((Math.random() * 6) + 1);

    $.notify({
      icon: 'notifications',
      message: message
    }, {
        type: type[color],
        timer: 1000,
        placement: {
          from: from,
          align: align
        }
      });
  }





}
