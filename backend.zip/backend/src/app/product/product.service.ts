import { Injectable } from '@angular/core';
import { DataService } from '../services/data.service';
import { Observable } from 'rxjs';
@Injectable()
export class ProductService {

    constructor(private dataService:DataService) { 
    
    }

    getProduct():Observable<any>
    {
      let url=this.dataService.baseApiPath+"catalog/products";
      return this.dataService.callRestful("GET",url);
    }

    addProduct(formDataArray:Array<any>):any
    {
      let url=this.dataService.baseApiPath+"admin/catalog/product";
     // let url="http://api.muahh.co.uk/v1/test";
      return this.dataService.callRestfulWithFormData("POST",url,formDataArray);
    }

    updateProduct(formDataArray:Array<any>):any
    {
      let url=this.dataService.baseApiPath+"admin/catalog/product/update";
      return this.dataService.callRestfulWithFormData("POST",url,formDataArray);
    }

    getProductById(id):Observable<any>
    {
      let url=this.dataService.baseApiPath+"catalog/product/"+id;
      return this.dataService.callRestful("GET",url);
    }

    deleteProduct(id):Observable<any>
    {
      let url=this.dataService.baseApiPath+"admin/catalog/product/"+id;
      return this.dataService.callRestful("DELETE",url);
    }

    
}