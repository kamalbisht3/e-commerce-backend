import { Component, OnInit } from '@angular/core';
import { ProductService } from './product.service';

declare var $:any;

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  productList: Array<any> = [];

  constructor(private productService: ProductService) { }

  ngOnInit() {
    this.getProductList();
  }

  getProductList() {
    this.productService.getProduct().subscribe((data) => {
      let res = data;
      if (res.status == "success") {
        this.productList = res.data;
      }
      //if(data=)
    })
  }

  deleteProduct(item) {
    this.productService.deleteProduct(item.id).subscribe((data) => {
      let res = data;
      if (res.status == "success") {
        this.showNotification("top","center","Product deleted Successfully")
        this.getProductList();
       // this.productList = res.data;
      }
      //if(data=)
    })
  }

  showNotification(from: any, align: any, message) {
    const type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

    const color = Math.floor((Math.random() * 6) + 1);

    $.notify({
      icon: 'notifications',
      message: message
    }, {
        type: type[color],
        timer: 1000,
        placement: {
          from: from,
          align: align
        }
      });
  }

}
