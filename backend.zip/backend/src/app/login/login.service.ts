import { Injectable } from '@angular/core';
import { DataService } from '../services/data.service';
import { Observable } from 'rxjs/Observable';
import { observableToBeFn } from 'rxjs/testing/TestScheduler';
@Injectable()
export class LoginService {

    constructor(private dataService: DataService) {

    }

    login(obj):Observable<any> {
        let url = this.dataService.baseApiPath + "user/login";
         return  this.dataService.callRestful("POST", url, { body: obj });
    }
}