import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { LoginService } from "./login.service";
import { LocalStorageService } from 'ngx-webstorage';
import { Router } from '@angular/router';
declare var $:any;
@Component({
    selector: 'login',
    templateUrl: 'login.component.html'
})

export class LoginComponent implements OnInit {
    loginFormGroup: FormGroup;
    constructor(private router:Router,private formBuilder: FormBuilder, private loginService: LoginService,private localStorageService:LocalStorageService) { }

    ngOnInit() {
        this.loginFormGroup = this.formBuilder.group(
            {
                email: ['muahhco@muahhco.co.uk', [Validators.required]],
                password: ['Newton@123', [Validators.required]]
            }
        )
    }

    login(formObject) {
       
        this.loginService.login(formObject).subscribe((data) => {
          let res=data;
          if(res.status=="success")
          {
           this.localStorageService.store('user',res.data);
           this.router.navigateByUrl('/tag');
          }
          else{
               this.showNotification("top","center",res.error.message[0]);
               
          }
        })
    }

    showNotification(from: any, align: any, message) {
        const type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];
    
        const color = Math.floor((Math.random() * 6) + 1);
    
        $.notify({
          icon: 'notifications',
          message: message
        }, {
            type: type[color],
            timer: 1000,
            placement: {
              from: from,
              align: align
            }
          });
      }
}