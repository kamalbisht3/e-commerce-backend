import { NgModule } from '@angular/core';

import { LoginComponent } from './login.component';
import { RouterModule } from '@angular/router'
import { LoginRoutes } from './login.routing';
import { ReactiveFormsModule } from '@angular/forms';
import { LoginService } from './login.service';
import { Ng2Webstorage } from 'ngx-webstorage';

@NgModule({
    imports: [RouterModule.forChild(LoginRoutes),
    ReactiveFormsModule,
    Ng2Webstorage],
    exports: [LoginComponent],
    declarations: [LoginComponent],
    providers: [LoginService],
})
export class LoginModule {

 }
