import { Injectable } from '@angular/core';
import { DataService } from '../services/data.service';
import { Observable } from 'rxjs';
@Injectable()
export class ProductVariantOptionService {

    constructor(private dataService:DataService) { 
    
    }

    getProduct():Observable<any>
    {
      let url=this.dataService.baseApiPath+"catalog/products";
      return this.dataService.callRestful("GET",url);
    }

    getVariantDetail(id):Observable<any>
    {
        let url=this.dataService.baseApiPath+"catalog/variant/"+id;
        return this.dataService.callRestful("GET",url);
    }

    getVariantOptionById(id)
    {
        let url=this.dataService.baseApiPath+"catalog/variant_option/"+id;
        return this.dataService.callRestful("GET",url);
    }

    addProductVariantOption(obj):Observable<any>
    {
      let url=this.dataService.baseApiPath+"admin/catalog/variant_option";
      return this.dataService.callRestful("POST",url,{body:obj});
    }

    updateProductVariantOption(obj):Observable<any>
    {
      let url=this.dataService.baseApiPath+"admin/catalog/variant_option/update";
      return this.dataService.callRestful("POST",url,{body:obj});
    }

    getProductById(id):Observable<any>
    {
      let url=this.dataService.baseApiPath+"catalog/product/"+id;
      return this.dataService.callRestful("GET",url);
    }

    deleteProductVariantOption(id):Observable<any>
    {
      let url=this.dataService.baseApiPath+"admin/catalog/variant_option/"+id;
      return this.dataService.callRestful("DELETE",url);
    }

    
}