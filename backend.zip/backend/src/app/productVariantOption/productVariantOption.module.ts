import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { ProductVariantOptionRoutes } from './productVariantOption.routing'
import { ProductVariantOptionComponent } from './productVariantOption.component';
import { AddProductVariantOptionComponent } from './addProductVariantOption/addProductVariantOption.component';
import { UpdateProductVariantOptionComponent } from './updateProductVariantOption/updateProductVariantOption.component';
import { ProductVariantOptionService } from './productVariantOption.service';
import { FieldErrorDisplayModule } from '../forms/validationforms/field-error-display/field-error-display.component';
import {
   
    MatSelectModule
  
  } from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(ProductVariantOptionRoutes),
    ReactiveFormsModule,
    MatSelectModule,
    FieldErrorDisplayModule
  ],
  declarations: [ProductVariantOptionComponent,
    AddProductVariantOptionComponent,
    UpdateProductVariantOptionComponent
],
providers:[ProductVariantOptionService]
})
export class ProductVariantOptionModule { }
