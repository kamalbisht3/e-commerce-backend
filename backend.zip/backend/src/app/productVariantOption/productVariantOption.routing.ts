import { Routes } from '@angular/router';
import { ProductVariantOptionComponent } from './productVariantOption.component';
import { AddProductVariantOptionComponent } from './addProductVariantOption/addProductVariantOption.component';
import { UpdateProductVariantOptionComponent } from './updateProductVariantOption/updateProductVariantOption.component';



export const ProductVariantOptionRoutes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                component: ProductVariantOptionComponent
            },
            {
                path: 'add/:id',
                component: AddProductVariantOptionComponent
            },
            {
                path: 'update/:id',
                component: UpdateProductVariantOptionComponent
            }
        ]
    }
];