import { Component, OnInit } from '@angular/core';
import { ProductVariantOptionService } from './productVariantOption.service';
declare var $:any;
@Component({
  selector: 'app-productVariantOption',
  templateUrl: './productVariantOption.component.html',
  styleUrls: ['./productVariantOption.component.css']
})
export class ProductVariantOptionComponent implements OnInit {

  productList: Array<any> = [];
  constructor(private productVariantOptionService: ProductVariantOptionService) { }

  ngOnInit() {
   this.getProductList();
  }

  getProductList() {
    //this.productVariantOptionService.
    this.productVariantOptionService.getProduct().subscribe((data) => {
      let res = data;
      if (res.status == "success") {
        this.productList = res.data;
      }
      //if(data=)
    })
  }

  deleteProductVariant(id) {
    this.productVariantOptionService.deleteProductVariantOption(id).subscribe((data) => {
       let res=data;
       if (res.status == "success") {
         this.getProductList();
         this.showNotification("top","center",res.data);
      }
      else{
        this.showNotification("top","center",res.error.message[0]);
        
      }

    })
  }

  showNotification(from: any, align: any, message) {
    const type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

    const color = Math.floor((Math.random() * 6) + 1);

    $.notify({
      icon: 'notifications',
      message: message
    }, {
        type: type[color],
        timer: 1000,
        placement: {
          from: from,
          align: align
        }
      });
  }

}
