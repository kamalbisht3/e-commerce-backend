import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { ProductVariantOptionService } from '../productVariantOption.service';
import { ActivatedRoute } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-addProductVariant',
  templateUrl: './updateProductVariantOption.component.html',
  styleUrls: ['./updateProductVariantOption.component.css']
})
export class UpdateProductVariantOptionComponent implements OnInit {

  addProductVariantFormGroup: FormGroup;

  variantOptionList: Array<any> = [];
  names: FormArray;
  constructor(private activatedRoute: ActivatedRoute, private productVariantOptionService: ProductVariantOptionService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    // this.getProductList();
    this.getProductById();
    this.addProductVariantFormGroup = this.formBuilder.group(
      {
        "names": this.formBuilder.array([this.createVariantForm()]),
        "variant_id": ['', [Validators.required]]
      }
    )
  }

  getProductById() {
    this.activatedRoute.params.subscribe((data) => {
      this.productVariantOptionService.getProductById(data['id']).subscribe((data) => {
        let res=data;
        if(res.status=="success")
        {
          this.variantOptionList=[];
          if(res.data.variants.length>0)
          {
             let variants=res.data.variants;
             variants.forEach(element => {
               element.variant_options.forEach(innerElement => {
                this.variantOptionList.push(innerElement);   
               });
              
             });
             this.setAttributesValue(this.variantOptionList);
          }
        }

      })
    })
  }



  createVariantForm() {
    return this.formBuilder.group(
      {
        name: ['', [Validators.required]],
        id: ['', [Validators.required]],
        variant_id: ['', [Validators.required]]
      }
    )
  }

  addNames(): void {
    this.names = this.addProductVariantFormGroup.get('names') as FormArray;
    this.names.push(this.createVariantForm());
  }

  removeNames(i) {
    this.names.removeAt(i);
  }

  // getProductList() {
  //   this.productVariantService.getProduct().subscribe((data) => {
  //     let res = data;
  //     if (res.status == "success") {
  //       this.productList = res.data;
  //       this.getProductById();
  //     }
  //     //if(data=)
  //   })
  // }



  

  getVariantValue(index) {
    this.names = this.addProductVariantFormGroup.get('names') as FormArray;
    this.updateProductVariant(this.names.value[index]);
  }

  setAttributesValue(value) {
    
    let control = <FormArray>this.addProductVariantFormGroup.controls.names;

    let length = control.length;
    while (length > 0) {
      control.removeAt(--length);
    }
    value.forEach(x => {
      control.push(this.formBuilder.group({ name: x.name, id: x.id, variant_id: x.variant_id }))
    });


  }

  deleteProductVariant(index) {
    this.names = this.addProductVariantFormGroup.get('names') as FormArray;
    let value = this.names.value[index];
    this.productVariantOptionService.deleteProductVariantOption(value.id).subscribe((data) => {
      let res = data;
      if (res.status == "success") {
        this.showNotification("top", "center", res.data);
        this.getProductById();
      }
      else
        this.showNotification("top", "center", res.error.message[0]);
    })
  }



  updateProductVariant(value) {
    // let names = [];
    // value.names.forEach((element) => {
    //   names.push(element.name);
    // });
    // let obj = {
    //   name: names,
    //   product_id: value.product_id
    // }

    this.productVariantOptionService.updateProductVariantOption(value).subscribe((data) => {
      let res = data;
      if (res.status == "success") {
        this.showNotification("top", "center", res.data);
        this.getProductById()
      }
      else
        this.showNotification("top", "center", res.error.message[0]);
    })
  }

  showNotification(from: any, align: any, message) {
    const type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

    const color = Math.floor((Math.random() * 6) + 1);

    $.notify({
      icon: 'notifications',
      message: message
    }, {
        type: type[color],
        timer: 1000,
        placement: {
          from: from,
          align: align
        }
      });
  }

  isFieldValid(form: FormGroup, field: string) {
    return !form.get(field).valid && form.get(field).touched;
  }

  displayFieldCss(form: FormGroup, field: string) {
    return {
      'has-error': this.isFieldValid(form, field),
      'has-feedback': this.isFieldValid(form, field)
    };
  }

}
