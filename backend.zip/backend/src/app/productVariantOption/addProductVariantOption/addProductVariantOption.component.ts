import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { ProductVariantOptionService } from '../productVariantOption.service';
import 'rxjs/add/operator/switchMap';
import { ActivatedRoute } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-addProductVariant',
  templateUrl: './addProductVariantOption.component.html',
  styleUrls: ['./addProductVariantOption.component.css']
})
export class AddProductVariantOptionComponent implements OnInit {

  addProductVariantFormGroup: FormGroup;

  variantList: Array<any> = [];
  names: FormArray;
  constructor(private activatedRoute: ActivatedRoute, private productVariantOptionService: ProductVariantOptionService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    //  this.getProductList();
    this.getVariantDetail();
    this.addProductVariantFormGroup = this.formBuilder.group(
      {
        "names": this.formBuilder.array([this.createVariantForm()]),
        "variant_id": ['', [Validators.required]]
      }
    )
  }

  createVariantForm() {
    return this.formBuilder.group(
      {
        name: ['', [Validators.required]]
      }
    )
  }

  addNames(): void {
    this.names = this.addProductVariantFormGroup.get('names') as FormArray;
    this.names.push(this.createVariantForm());
  }

  removeNames(i) {
    this.names.removeAt(i);
  }

  getVariantDetail() {
    this.activatedRoute.params.subscribe((data)=>
      this.productVariantOptionService.getVariantDetail(data['id']).subscribe((data) => {
        let res=data;
        if(res.status=="success")
        {
         this.variantList=res.data;
        }
      }))
  }

  // getProductList() {
  //   this.productVariantOptionService.getProduct().subscribe((data) => {
  //     let res = data;
  //     if (res.status == "success") {
  //       this.productList = res.data;
  //     }
  //     //if(data=)
  //   })
  // }

  addProductVariant(value) {
    let names = [];
    value.names.forEach((element) => {
      names.push(element.name);
    });
    let obj = {
      name: names,
      variant_id: value.variant_id
    }
    this.productVariantOptionService.addProductVariantOption(obj)
      .subscribe((data) => {
        let res: any = data;
        if (res.status == "success") {
          this.showNotification("top", "center", "Product Variant Option Created Successfully");
        }
        else
          this.showNotification("top", "center", res.error.message[0]);
      })
  }

  showNotification(from: any, align: any, message) {
    const type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

    const color = Math.floor((Math.random() * 6) + 1);

    $.notify({
      icon: 'notifications',
      message: message
    }, {
        type: type[color],
        timer: 1000,
        placement: {
          from: from,
          align: align
        }
      });
  }

  isFieldValid(form: FormGroup, field: string) {
    return !form.get(field).valid && form.get(field).touched;
  }

  displayFieldCss(form: FormGroup, field: string) {
    return {
      'has-error': this.isFieldValid(form, field),
      'has-feedback': this.isFieldValid(form, field)
    };
  }

}

