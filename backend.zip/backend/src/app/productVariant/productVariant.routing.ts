import { Routes } from '@angular/router';
import { ProductVariantComponent } from './productVariant.component';
import { AddProductVariantComponent } from './addProductVariant/addProductVariant.component';
import { UpdateProductVariantComponent } from './updateProductVariant/updateProductVariant.component';



export const ProductVariantRoutes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                component: ProductVariantComponent
            },
            {
                path: 'add',
                component: AddProductVariantComponent
            },
            {
                path: 'update/:id',
                component: UpdateProductVariantComponent
            }
        ]
    }
];