import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { ProductVariantRoutes } from './productVariant.routing';
import { ProductVariantComponent } from './productVariant.component';
import { AddProductVariantComponent } from './addProductVariant/addProductVariant.component';
import { UpdateProductVariantComponent } from './updateProductVariant/updateProductVariant.component';
import { FieldErrorDisplayModule } from '../forms/validationforms/field-error-display/field-error-display.component';
import { MatSelectModule } from '@angular/material';
import { ProductVariantService } from './productVariant.service';
@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule.forChild(ProductVariantRoutes),
    MatSelectModule,
    FieldErrorDisplayModule

  ],
  declarations: [ProductVariantComponent,
    AddProductVariantComponent,
    UpdateProductVariantComponent
  ],
  providers: [ProductVariantService]
})
export class ProductVariantModule { }
