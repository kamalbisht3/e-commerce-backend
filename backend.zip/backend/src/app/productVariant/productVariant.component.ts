import { Component, OnInit } from '@angular/core';
import { ProductVariantService } from './productVariant.service';
declare var $:any;
@Component({
  selector: 'app-productVariant',
  templateUrl: './productVariant.component.html',
  styleUrls: ['./productVariant.component.css']
})
export class ProductVariantComponent implements OnInit {

  productList: Array<any> = [];
  constructor(private productVariantService: ProductVariantService) { }

  ngOnInit() {
    this.getProductList();
  }

  getProductList() {
    this.productVariantService.getProduct().subscribe((data) => {
      let res = data;
      if (res.status == "success") {
        this.productList = res.data;
      }
      //if(data=)
    })
  }

  deleteProductVariant(id) {
    this.productVariantService.deleteProductVariant(id).subscribe((data) => {
       let res=data;
       if (res.status == "success") {
         this.getProductList();
         this.showNotification("top","center",res.data);
      }
      else{
        this.showNotification("top","center",res.error.message[0]);
        
      }

    })
  }

  showNotification(from: any, align: any, message) {
    const type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

    const color = Math.floor((Math.random() * 6) + 1);

    $.notify({
      icon: 'notifications',
      message: message
    }, {
        type: type[color],
        timer: 1000,
        placement: {
          from: from,
          align: align
        }
      });
  }

}
