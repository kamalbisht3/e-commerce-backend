import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { ProductVariantService } from '../productVariant.service';
import { ActivatedRoute } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-addProductVariant',
  templateUrl: './updateProductVariant.component.html',
  styleUrls: ['./updateProductVariant.component.css']
})
export class UpdateProductVariantComponent implements OnInit {

  addProductVariantFormGroup: FormGroup;

  productList: Array<any> = [];
  names: FormArray;
  constructor(private activatedRoute: ActivatedRoute, private productVariantService: ProductVariantService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.getProductList();
    //this.getProductById();
    this.addProductVariantFormGroup = this.formBuilder.group(
      {
        "names": this.formBuilder.array([this.createVariantForm()]),
        "product_id": ['', [Validators.required]]
      }
    )
  }

  createVariantForm() {
    return this.formBuilder.group(
      {
        name: ['', [Validators.required]],
        id: [],
        product_id: []
      }
    )
  }

  addNames(): void {
    this.names = this.addProductVariantFormGroup.get('names') as FormArray;
    this.names.push(this.createVariantForm());
  }

  removeNames(i) {
    this.names.removeAt(i);
  }

  getProductList() {
    this.productVariantService.getProduct().subscribe((data) => {
      let res = data;
      if (res.status == "success") {
        this.productList = res.data;
        this.getProductById();
      }
      //if(data=)
    })
  }



  getProductById() {
    this.activatedRoute.params.subscribe((data) => {
      let productId = data['id'];
      this.productVariantService.getProductById(productId).subscribe((data) => {
        let res = data;
        if (res.status == "success") {
          this.addProductVariantFormGroup.controls['product_id'].setValue(res.data.id);
          this.setAttributesValue(res.data.variants);
        }
      })
    })
  }

  getVariantValue(index) {
    this.names = this.addProductVariantFormGroup.get('names') as FormArray;
    this.updateProductVariant(this.names.value[index]);
  }

  setAttributesValue(value) {

    let control = <FormArray>this.addProductVariantFormGroup.controls.names;

    let length = control.length;
    while (length > 0) {
      control.removeAt(--length);
    }
    value.forEach(x => {
      control.push(this.formBuilder.group({ name: x.name, id: x.id, product_id: x.product_id }))
    });


  }

  deleteProductVariant(index) {
    this.names = this.addProductVariantFormGroup.get('names') as FormArray;
    let value = this.names.value[index];
    this.productVariantService.deleteProductVariant(value.id).subscribe((data) => {
      let res = data;
      if (res.status == "success") {
        this.showNotification("top", "center", res.data);
        this.getProductById();
      }
      else
        this.showNotification("top", "center", res.error.message[0]);
    })
  }



  updateProductVariant(value) {
    // let names = [];
    // value.names.forEach((element) => {
    //   names.push(element.name);
    // });
    // let obj = {
    //   name: names,
    //   product_id: value.product_id
    // }

    this.productVariantService.updateProductVariant(value).subscribe((data) => {
      let res = data;
      if (res.status == "success") {
        this.showNotification("top", "center", res.data);
        this.getProductById()
      }
      else
        this.showNotification("top", "center", res.error.message[0]);
    })
  }

  showNotification(from: any, align: any, message) {
    const type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

    const color = Math.floor((Math.random() * 6) + 1);

    $.notify({
      icon: 'notifications',
      message: message
    }, {
        type: type[color],
        timer: 1000,
        placement: {
          from: from,
          align: align
        }
      });
  }

  isFieldValid(form: FormGroup, field: string) {
    return !form.get(field).valid && form.get(field).touched;
  }

  displayFieldCss(form: FormGroup, field: string) {
    return {
      'has-error': this.isFieldValid(form, field),
      'has-feedback': this.isFieldValid(form, field)
    };
  }

}
