import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { ProductVariantService } from '../productVariant.service';
import  'rxjs/add/operator/switchMap';
declare var $: any;
@Component({
  selector: 'app-addProductVariant',
  templateUrl: './addProductVariant.component.html',
  styleUrls: ['./addProductVariant.component.css']
})
export class AddProductVariantComponent implements OnInit {

  addProductVariantFormGroup: FormGroup;

  productList: Array<any> = [];
  names: FormArray;
  constructor(private productVariantService: ProductVariantService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.getProductList();
    this.addProductVariantFormGroup = this.formBuilder.group(
      {
        "names": this.formBuilder.array([this.createVariantForm()]),
        "product_id": ['', [Validators.required]]
      }
    )
  }

  createVariantForm() {
    return this.formBuilder.group(
      {
        name: ['', [Validators.required]]
      }
    )
  }

  addNames(): void {
    this.names = this.addProductVariantFormGroup.get('names') as FormArray;
    this.names.push(this.createVariantForm());
  }

  removeNames(i) {
    this.names.removeAt(i);
  }

  getProductList() {
    this.productVariantService.getProduct().subscribe((data) => {
      let res = data;
      if (res.status == "success") {
        this.productList = res.data;
      }
      //if(data=)
    })
  }

  addProductVariant(value) {
    debugger;
    let names = [];
    value.names.forEach((element) => {
      names.push(element.name);
    });
    let obj = {
      name: names,
      product_id: value.product_id
    }
    this.productVariantService.addProductVariant(obj)
      .subscribe((data) => {
        debugger;
        let res:any = data;
        if (res.status == "success") {
          this.showNotification("top", "center", "Product Variant Created Successfully");
        }
        else
          this.showNotification("top", "center", res.error.message[0]);
      })
  }

  showNotification(from: any, align: any, message) {
    const type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

    const color = Math.floor((Math.random() * 6) + 1);

    $.notify({
      icon: 'notifications',
      message: message
    }, {
        type: type[color],
        timer: 1000,
        placement: {
          from: from,
          align: align
        }
      });
  }

  isFieldValid(form: FormGroup, field: string) {
    return !form.get(field).valid && form.get(field).touched;
  }

  displayFieldCss(form: FormGroup, field: string) {
    return {
      'has-error': this.isFieldValid(form, field),
      'has-feedback': this.isFieldValid(form, field)
    };
  }

}
