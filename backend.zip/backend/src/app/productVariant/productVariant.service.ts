import { Injectable } from '@angular/core';
import { DataService } from '../services/data.service';
import { Observable } from 'rxjs';
@Injectable()
export class ProductVariantService {

    constructor(private dataService:DataService) { 
    
    }

    getProduct():Observable<any>
    {
      let url=this.dataService.baseApiPath+"catalog/products";
      return this.dataService.callRestful("GET",url);
    }

    addProductVariant(obj):Observable<any>
    {
      let url=this.dataService.baseApiPath+"admin/catalog/variant";
      return this.dataService.callRestful("POST",url,{body:obj});
    }

    updateProductVariant(obj):Observable<any>
    {
      let url=this.dataService.baseApiPath+"admin/catalog/variant/update";
      return this.dataService.callRestful("POST",url,{body:obj});
    }

    getProductById(id):Observable<any>
    {
      let url=this.dataService.baseApiPath+"catalog/product/"+id;
      return this.dataService.callRestful("GET",url);
    }

    deleteProductVariant(id):Observable<any>
    {
      let url=this.dataService.baseApiPath+"admin/catalog/variant/"+id;
      return this.dataService.callRestful("DELETE",url);
    }

    
}