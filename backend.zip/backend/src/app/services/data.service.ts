

import { Injectable } from '@angular/core';
import { Response, Headers, RequestOptions, Http, URLSearchParams } from "@angular/http";
import { Observable, Subject } from "rxjs";
import { LocalStorageService } from 'ngx-webstorage';


import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import { Session } from 'protractor';
import {
    HttpResponse,
    HttpRequest, HttpHandler, HttpClient, HttpHeaders,
    HttpEvent,
    HttpInterceptor, HttpErrorResponse
} from '@angular/common/http';
declare const $: any;
import { ErrorObservable } from 'rxjs/observable/ErrorObservable'
@Injectable()
export class DataService {
    api: any;

    baseApiPath: string;


    constructor(private _http: Http, private httpClient: HttpClient, private localStorageService: LocalStorageService) {
        this.baseApiPath = "http://api.muahh.co.uk/v1/";
    }

    getToken(): string {
        let token = "d6a28e17ac8190f6f5ff122bdd37a1e42b81a3c5000983992d97955a6a2899ae";
        return token;
    }

    getSession(): string {
        let session;
        if (this.localStorageService.retrieve('user')) {
            let user = this.localStorageService.retrieve('user');
            session = user.session_id;
            return session;
        }
        else
        return null;
    }

    callRestful(type: string, url: string, options?: { params?: {}, body?: {} }) {
        let httpHeaders = {
            headers: new HttpHeaders()
                .set("Content-Type", "'application/json'")
                .set("oauth", this.getToken())
                .set("session", this.getSession()?this.getSession():"")
        };
        
        switch (type) {
            case "GET":
                return this.httpClient.get<any>(url, httpHeaders).catch(err => this.handleError(err));
            case "POST":
                return this.httpClient.post<any>(url, options.body, httpHeaders).catch(err => this.handleError(err));
            case "PUT":
                return this.httpClient.put<any>(url, options.body, httpHeaders).catch(err => this.handleError(err));
            case "DELETE":
                return this.httpClient.delete<any>(url, httpHeaders).catch(err => this.handleError(err));
            default:
                return null;
        }
    }

    callRestfulOld(type: string, url: string, options?: { params?: {}, body?: {} }) {
        // console.log(type, ' ', url);

        let requestOptionArgs = {};
        let searchParams;
        let body;

        if (options != undefined && options['params'] != undefined)
            searchParams = options['params'];
        if (options != undefined && options['body'] != undefined)
            body = options['body'];


        let headerData = {
            'Content-Type': 'application/json',
            'oauth': this.getToken(),
            'session': this.getSession()
            //'Content-Type': 'application/x-www-form-urlencoded',
            /*'Access-Control-Allow-Origin':'*',
             'Access-Control-Allow-Credentials':true,*/
            //,  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE'
        };



        let headers = new Headers(headerData);

        requestOptionArgs["headers"] = headers;

        if (searchParams != undefined && Object.keys(searchParams).length > 0) {
            let urlSearchParams = new URLSearchParams();
            for (let key in searchParams) {
                urlSearchParams.set(key, searchParams[key]);
            }
            requestOptionArgs["search"] = urlSearchParams;
        }

        if (body != undefined && Object.keys(body).length > 0) {
            requestOptionArgs["body"] = body;
        }

        let requestOptions = new RequestOptions(requestOptionArgs);
        //alert('start');
        switch (type) {
            case 'GET':
                return this._http.get(url, requestOptions).map(res => {
                    return res;
                }).catch(err => this.handleError(err));
            case 'POST':
                return this._http.post(url, body, requestOptions).map(res => res).catch(err => this.handleError(err));
            case 'PUT':
                return this._http.put(url, body, requestOptions).map(res => res).catch(err => this.handleError(err));
            case 'DELETE':
                return this._http.delete(url, requestOptions).map(res => res).catch(err => this.handleError(err));
            default:
                //console.log('Debug at type request ' + type);
                return null;
        }
    }



    callRestfulWithFormData(method, url: string, formDataArray: Array<any>): any {
        var fd = new FormData();
        formDataArray.forEach((element) => {
            fd.append(element.key, element.value)
        })

        var xhr = new XMLHttpRequest();

        xhr.open(method, url, true);
        xhr.setRequestHeader("oauth", this.getToken());
        xhr.setRequestHeader("session", this.getSession());
        xhr.send(fd);
        return xhr;
    }

    private handleError(error: HttpErrorResponse) {
        // if (error.error instanceof ErrorEvent) {
        //   // A client-side or network error occurred. Handle it accordingly.
        //   console.error('An error occurred:', error.error.message);
        // } else {
        //   // The backend returned an unsuccessful response code.
        //   // The response body may contain clues as to what went wrong,
        //   console.error(
        //     `Backend returned code ${error.status}, ` +
        //     `body was: ${error.statusText}`);
        // }
        this.showNotification("top", "center", error.statusText);
        // return an ErrorObservable with a user-facing error message
        return new ErrorObservable(
            'Something bad happened; please try again later.');
    };


    // private handleError(error: Response | any) {
    //     // console.log(error.statusText);        // let event = error;
    //     this.showNotification("top","center",error.statusText);

    //     return Observable.throw(error);
    // }

    showNotification(from: any, align: any, message) {
        const type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

        const color = Math.floor((Math.random() * 6) + 1);

        $.notify({
            icon: 'notifications',
            message: message
        }, {
                type: type[color],
                timer: 1000,
                placement: {
                    from: from,
                    align: align
                }
            });
    }






}

