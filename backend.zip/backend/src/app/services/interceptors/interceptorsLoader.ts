import { Injectable ,ViewChild } from '@angular/core';
import { HttpRequest, HttpResponse, HttpEvent, HttpHandler, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';
import  'rxjs/add/operator/do';
import { LoaderService } from '../../shared/loader/loader.component.service';

@Injectable()
export class InterceptorLoaderService implements HttpInterceptor {
  constructor(private loaderService:LoaderService)
  {

  }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // start our loader here
    //this._loadingBar.start();
   
    this.loaderService.start();
    //this.loaderService.isShowLoaderSubject.next(true);
    return next.handle(req).do((event: HttpEvent<any>) => {
      // if the event is for http response
      if (event instanceof HttpResponse) {
        // stop our loader here
        //  this._loadingBar.complete();
      
        this.loaderService.stop();
      }

    }, (err: any) => {
      this.loaderService.stop();
      // if any error (not for just HttpResponse) we stop our loader bar
      //  this._loadingBar.complete();
      
    });
    // return next.handle(req);
  }

} 