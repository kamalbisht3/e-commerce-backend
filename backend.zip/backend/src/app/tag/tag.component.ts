import { Component, OnInit } from '@angular/core';
import { TagService } from './tag.service';

@Component({
    selector: 'tag',
    templateUrl: 'tag.component.html'
})

export class TagComponent implements OnInit {
    tagList: Array<any> = [];
    constructor(private tagService: TagService) { }

    ngOnInit() {
        this.getTags();
    }

    getTags() {
        this.tagService.getTag().subscribe((data) => {
            let res = data;
            if (res.status == "success") {
                this.tagList = res.data;
            }
        })
    }

    deleteTag(item) {
        this.tagService.deleteTag(item.id).subscribe((data) => {
           this.getTags();
        })
    }
}