import { Routes } from '@angular/router';
import { TagComponent } from './tag.component';
import { AddTagComponent } from './addTag/addTag.component';
import { UpdateTagComponent } from './updateTag/updateTag.component';



export const TagRoutes: Routes = [
    {
        path: '',
        children: [{
            path: '',
            component: TagComponent
        },
        {
            path: 'add',
            component: AddTagComponent
        },
        {
            path: 'update/:id',
            component: UpdateTagComponent
        }]
    }
];