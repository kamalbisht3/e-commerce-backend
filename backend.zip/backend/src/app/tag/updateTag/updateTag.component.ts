import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TagService } from '../tag.service';
import { ActivatedRoute } from '@angular/router';
declare const $: any;

@Component({
    selector: 'update-tag',
    templateUrl: 'updateTag.component.html'
})

export class UpdateTagComponent implements OnInit {
    constructor(private activatedRoute: ActivatedRoute, private formBuilder: FormBuilder, private tagService: TagService) { }

    addTagFormGroup: FormGroup;



    ngOnInit() {
        this.activatedRoute.params.subscribe((data) => {
            this.getTagById(data['id']);
        })
        this.addTagFormGroup = this.formBuilder.group(
            {
                "name": ['', [Validators.required]],
                "id": ['', [Validators.required]]
            }
        )
    }

    getTagById(id) {
        this.tagService.getTagById(id).subscribe((data) => {
            let res = data;
            if (res.status = "success") {
                this.addTagFormGroup.controls['name'].setValue(res.data.name);
                this.addTagFormGroup.controls['id'].setValue(res.data.id);
            }

        })
    }

    updateTag(value) {
        
        this.tagService.updateTag(value).subscribe((data) => {
            let res = data;
            if (res.status = "success") {
                this.showNotification('top','center',res.data);
            }
            else{
                this.showNotification('top','center',"Some Thing Wrong");
            }

        })
    }

    isFieldValid(form: FormGroup, field: string) {
        return !form.get(field).valid && form.get(field).touched;
    }

    displayFieldCss(form: FormGroup, field: string) {
        return {
            'has-error': this.isFieldValid(form, field),
            'has-feedback': this.isFieldValid(form, field)
        };
    }

    showNotification(from: any, align: any,message) {
        const type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

        const color = Math.floor((Math.random() * 6) + 1);

        $.notify({
            icon: 'notifications',
            message: message
        }, {
            type: type[color],
            timer: 1000,
            placement: {
                from: from,
                align: align
            }
        });
    }

   

}