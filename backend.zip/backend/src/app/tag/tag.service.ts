import { Injectable } from '@angular/core';
import { DataService } from '../services/data.service';
import { Observable } from 'rxjs/Observable';
@Injectable()
export class TagService {

    constructor(private dataService: DataService) {

    }

    getTag(): Observable<any>  {
        let url = this.dataService.baseApiPath + "catalog/tags";
        return this.dataService.callRestful("GET", url);
    }

    addTag(obj): Observable<any> {
        let url = this.dataService.baseApiPath + "catalog/tag";
        return this.dataService.callRestful("POST", url,{body:obj});
    }
    deleteTag(id): Observable<any>  {
        let url = this.dataService.baseApiPath + "catalog/tag/"+id;
        return this.dataService.callRestful("DELETE", url);
    }

    updateTag(obj): Observable<any>  {
        let url = this.dataService.baseApiPath + "catalog/tag";
        return this.dataService.callRestful("PUT", url,{body:obj});
    }

    getTagById(id): Observable<any>  {
        let url = this.dataService.baseApiPath + "catalog/tag/"+id;
        return this.dataService.callRestful("GET", url);
    }

}