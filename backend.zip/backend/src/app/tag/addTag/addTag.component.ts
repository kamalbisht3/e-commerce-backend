import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TagService } from '../tag.service';
declare const $: any;
@Component({
    selector: 'add-tag',
    templateUrl: 'addTag.component.html'
})

export class AddTagComponent implements OnInit {
    constructor(private formBuilder: FormBuilder, private tagService: TagService) { }

    addTagFormGroup: FormGroup;



    ngOnInit() {
        this.addTagFormGroup = this.formBuilder.group(
            {
                "name": ['', [Validators.required]]
            }
        )
    }

    addTag(value) {
        this.tagService.addTag(value).subscribe((data) => {

            let res = data;
            if (res.status = "success") {
                this.showNotification('top', 'center', "Added Successfully");
            }
            else {
                this.showNotification('top', 'center', "Some Thing Wrong");
            }
        })
    }

    showNotification(from: any, align: any, message) {
        const type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

        const color = Math.floor((Math.random() * 6) + 1);

        $.notify({
            icon: 'notifications',
            message: message
        }, {
                type: type[color],
                timer: 1000,
                placement: {
                    from: from,
                    align: align
                }
            });
    }

    isFieldValid(form: FormGroup, field: string) {
        return !form.get(field).valid && form.get(field).touched;
    }

    displayFieldCss(form: FormGroup, field: string) {
        return {
            'has-error': this.isFieldValid(form, field),
            'has-feedback': this.isFieldValid(form, field)
        };
    }

}