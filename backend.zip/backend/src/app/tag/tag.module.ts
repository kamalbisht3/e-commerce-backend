import { NgModule } from '@angular/core';

import { TagComponent } from './tag.component';
import { RouterModule } from '@angular/router';
import { TagRoutes } from './tag.routing';
import { TagService } from './tag.service';
import { CommonModule } from '@angular/common';

import { AddTagComponent } from './addTag/addTag.component';
import { UpdateTagComponent } from './updateTag/updateTag.component';
import { ReactiveFormsModule } from '@angular/forms';
//import { FieldErrorDisplayModule } from 'validationforms/field-error-display/field-error-display.component';
import { FieldErrorDisplayModule } from '../forms/validationforms/field-error-display/field-error-display.component';
@NgModule({
    imports: [RouterModule.forChild(TagRoutes),
        CommonModule,
        ReactiveFormsModule,
        FieldErrorDisplayModule],
    exports: [TagComponent],
    declarations: [TagComponent,
        AddTagComponent,
        UpdateTagComponent],
    providers: [TagService],
})
export class TagModule { }
